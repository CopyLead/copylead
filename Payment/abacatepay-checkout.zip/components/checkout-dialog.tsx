"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, QrCode, CheckCircle2, XCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CheckoutDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  totalAmount: number
  productName: string
}

interface QRCodeResponse {
  id: string
  qrCodeBase64: string
  brCode: string
  status: string
  amount: number
  expiresAt: string
}

export function CheckoutDialog({ open, onOpenChange, totalAmount, productName }: CheckoutDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    cpf: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [qrCodeData, setQrCodeData] = useState<QRCodeResponse | null>(null)
  const [apiResponse, setApiResponse] = useState<any>(null)
  const [apiError, setApiError] = useState<any>(null)
  const { toast } = useToast()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .replace(/(-\d{2})\d+?$/, "$1")
  }

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{4})\d+?$/, "$1")
  }

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value)
    setFormData((prev) => ({ ...prev, cpf: formatted }))
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value)
    setFormData((prev) => ({ ...prev, phone: formatted }))
  }

  const handleCreateQRCode = async () => {
    // Validação básica
    if (!formData.name || !formData.phone || !formData.email || !formData.cpf) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setApiError(null)
    setApiResponse(null)

    try {
      const response = await fetch("/api/create-qrcode", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: totalAmount,
          customer: {
            name: formData.name,
            phone: formData.phone,
            email: formData.email,
            cpf: formData.cpf.replace(/\D/g, ""),
          },
          productName,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setApiError(data)
        throw new Error(data.error || "Erro ao gerar QR Code")
      }

      setApiResponse(data)
      setQrCodeData(data)
      toast({
        title: "QR Code gerado!",
        description: "Escaneie o código para realizar o pagamento.",
      })
    } catch (error) {
      console.error("[v0] Error creating QR code:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao gerar QR Code",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleClose = () => {
    setFormData({ name: "", phone: "", email: "", cpf: "" })
    setQrCodeData(null)
    setApiResponse(null)
    setApiError(null)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Finalizar Compra - {productName}</DialogTitle>
          <DialogDescription>
            {qrCodeData
              ? "Escaneie o QR Code para pagar com PIX"
              : "Preencha seus dados para gerar o QR Code de pagamento"}
          </DialogDescription>
        </DialogHeader>

        {!qrCodeData ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <Input
                id="name"
                name="name"
                placeholder="João Silva"
                value={formData.name}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                name="phone"
                placeholder="(11) 99999-9999"
                value={formData.phone}
                onChange={handlePhoneChange}
                maxLength={15}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="joao@exemplo.com"
                value={formData.email}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cpf">CPF</Label>
              <Input
                id="cpf"
                name="cpf"
                placeholder="000.000.000-00"
                value={formData.cpf}
                onChange={handleCPFChange}
                maxLength={14}
              />
            </div>

            <div className="rounded-lg bg-muted p-4">
              <p className="text-sm font-medium">Total a pagar:</p>
              <p className="text-2xl font-bold">R$ {totalAmount.toFixed(2)}</p>
            </div>

            <Button className="w-full" onClick={handleCreateQRCode} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando QR Code...
                </>
              ) : (
                <>
                  <QrCode className="mr-2 h-4 w-4" />
                  Criar QR Code
                </>
              )}
            </Button>

            {apiError && (
              <div className="space-y-2 rounded-lg border-2 border-destructive bg-destructive/10 p-4">
                <div className="flex items-center gap-2 text-destructive">
                  <XCircle className="h-5 w-5" />
                  <h3 className="font-semibold">Erro na Requisição</h3>
                </div>
                <pre className="max-h-60 overflow-auto rounded bg-background p-3 text-xs">
                  {JSON.stringify(apiError, null, 2)}
                </pre>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="rounded-lg border-2 border-border p-4">
                <img src={`data:image/png;base64,${qrCodeData.qrCodeBase64}`} alt="QR Code PIX" className="h-64 w-64" />
              </div>

              <div className="w-full space-y-2">
                <Label>Código PIX (Copia e Cola)</Label>
                <div className="flex gap-2">
                  <Input value={qrCodeData.brCode} readOnly className="font-mono text-xs" />
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(qrCodeData.brCode)
                      toast({
                        title: "Copiado!",
                        description: "Código PIX copiado para a área de transferência.",
                      })
                    }}
                  >
                    Copiar
                  </Button>
                </div>
              </div>

              <div className="w-full rounded-lg bg-muted p-4 text-center">
                <p className="text-sm text-muted-foreground">Status do pagamento:</p>
                <p className="text-lg font-semibold capitalize">{qrCodeData.status}</p>
              </div>
            </div>

            {apiResponse && (
              <div className="space-y-2 rounded-lg border-2 border-primary bg-primary/10 p-4">
                <div className="flex items-center gap-2 text-primary">
                  <CheckCircle2 className="h-5 w-5" />
                  <h3 className="font-semibold">Resposta da API (Sucesso)</h3>
                </div>
                <pre className="max-h-60 overflow-auto rounded bg-background p-3 text-xs">
                  {JSON.stringify(apiResponse, null, 2)}
                </pre>
              </div>
            )}

            <Button className="w-full bg-transparent" variant="outline" onClick={handleClose}>
              Fechar
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

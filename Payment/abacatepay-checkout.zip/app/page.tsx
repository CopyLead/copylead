"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckoutDialog } from "@/components/checkout-dialog"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap } from "lucide-react"

export default function Home() {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)

  const productName = "Ativação CopyLead"
  const productPrice = 10.0

  return (
    <main className="min-h-screen bg-gradient-to-br from-background to-muted p-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8 text-center">
          <h1 className="mb-2 text-4xl font-bold">CopyLead</h1>
          <p className="text-muted-foreground">Ative sua conta agora</p>
        </div>

        <Card className="border-2">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">{productName}</CardTitle>
            <CardDescription>Ative sua conta CopyLead e comece a criar copies incríveis</CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="rounded-lg bg-muted p-6 text-center">
              <p className="mb-2 text-sm text-muted-foreground">Valor da ativação</p>
              <p className="text-5xl font-bold text-primary">R$ {productPrice.toFixed(2)}</p>
            </div>

            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <span className="mt-1 text-primary">✓</span>
                <span>Acesso completo à plataforma CopyLead</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1 text-primary">✓</span>
                <span>Geração ilimitada de copies</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1 text-primary">✓</span>
                <span>Suporte prioritário</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1 text-primary">✓</span>
                <span>Atualizações gratuitas</span>
              </li>
            </ul>
          </CardContent>

          <CardFooter>
            <Button className="w-full" size="lg" onClick={() => setIsCheckoutOpen(true)}>
              Finalizar Compra
            </Button>
          </CardFooter>
        </Card>

        <CheckoutDialog
          open={isCheckoutOpen}
          onOpenChange={setIsCheckoutOpen}
          totalAmount={productPrice}
          productName={productName}
        />
      </div>
    </main>
  )
}

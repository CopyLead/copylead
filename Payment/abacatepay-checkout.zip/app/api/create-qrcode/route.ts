import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { amount, customer } = body

    // Validação dos dados
    if (!amount || !customer) {
      return NextResponse.json({ error: "Dados incompletos" }, { status: 400 })
    }

    // Chave da API do AbacatePay (deve ser configurada nas variáveis de ambiente)
    const apiKey = process.env.ABACATEPAY_API_KEY

    if (!apiKey) {
      console.error("[v0] ABACATEPAY_API_KEY not configured")
      return NextResponse.json({ error: "Configuração da API não encontrada" }, { status: 500 })
    }

    const response = await fetch("https://api.abacatepay.com/v1/pixQrCode/create", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: Math.round(amount * 100), // Converter para centavos
        expiresIn: 3600, // 1 hora em segundos
        description: "Compra na loja",
        customer: {
          name: customer.name,
          cellphone: customer.phone,
          email: customer.email,
          taxId: customer.cpf,
        },
        metadata: {
          externalId: `order_${Date.now()}`,
        },
      }),
    })

    const result = await response.json()

    if (!response.ok || result.error) {
      console.error("[v0] AbacatePay API error:", result)
      return NextResponse.json({ error: result.error || "Erro ao criar QR Code" }, { status: response.status })
    }

    const { data } = result

    return NextResponse.json({
      id: data.id,
      qrCodeBase64: data.brCodeBase64.replace("data:image/png;base64,", ""),
      brCode: data.brCode,
      status: data.status,
      amount: data.amount,
      expiresAt: data.expiresAt,
    })
  } catch (error) {
    console.error("[v0] Error in create-qrcode route:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
